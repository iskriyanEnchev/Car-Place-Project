export const loginSuccess = (user) => ({
    type: 'LOGIN_SUCCESS',
    payload: user
  });
  export const logOutSuccess = () => ({
    type: 'LOGOUT_SUCCESS',
  });

